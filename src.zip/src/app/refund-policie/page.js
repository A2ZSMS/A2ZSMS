import React from "react";
import Refund from "../Component/TermsPrivacy/Refund";

const page = () => {
  return (
    <div>
      <Refund />
    </div>
  );
};

export default page;
